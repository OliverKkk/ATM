-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 25, 2013 at 08:00 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `bankdb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admin`
-- 

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `name` varchar(20) default NULL,
  `username` varchar(15) default NULL,
  `password` varchar(15) default NULL,
  `date` datetime default NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1235 ;

-- 
-- Dumping data for table `admin`
-- 

INSERT INTO `admin` (`admin_id`, `name`, `username`, `password`, `date`) VALUES 
(1234, 'beato', 'beato', 'bea', '2013-04-20 11:51:41');

-- --------------------------------------------------------

-- 
-- Table structure for table `bankregistration`
-- 

CREATE TABLE `bankregistration` (
  `bankid` varchar(11) NOT NULL,
  `bankname` varchar(10) default NULL,
  `headoffice` varchar(10) default NULL,
  `address` varchar(30) default NULL,
  `town` varchar(15) default NULL,
  `location` varchar(15) default NULL,
  `email` varchar(25) default NULL,
  `manager` varchar(15) default NULL,
  `fax` int(11) default NULL,
  `telephone` int(11) default NULL,
  PRIMARY KEY  (`bankid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `bankregistration`
-- 

INSERT INTO `bankregistration` (`bankid`, `bankname`, `headoffice`, `address`, `town`, `location`, `email`, `manager`, `fax`, `telephone`) VALUES 
('e0011', 'equity', 'nairobi', 'p.o box 8789 nairobi', 'githurai', 'zimmer man', 'equity@eq.com', 'birgen', 787998, 723657451),
('k001', 'KCB', 'mombasa', 'p.o box 678 mombasa', 'MALINDI', 'KISAUNI', 'mombasakcb@kcb.com', 'MULI', 7898, 78665778),
('n001', 'NATIONAL ', 'KISUMU', 'P.O BOX 456 KISUMU', 'KISUMU', 'KISUMU WESTERN', 'nationbank@ntnbank.com', 'OTIENO', 689900, 2147483647);

-- --------------------------------------------------------

-- 
-- Table structure for table `clientdetails`
-- 

CREATE TABLE `clientdetails` (
  `surname` varchar(20) default NULL,
  `othername` varchar(30) default NULL,
  `client_id` int(11) default NULL,
  `address` varchar(30) default NULL,
  `gender` varchar(6) default NULL,
  `bankname` varchar(15) default NULL,
  `birth_date` date default NULL,
  `nationality` varchar(20) default NULL,
  `division` varchar(20) default NULL,
  `location` varchar(20) default NULL,
  `sublocation` varchar(20) default NULL,
  `email` varchar(30) default NULL,
  `mobile_no` int(11) default NULL,
  `added_by` varchar(20) default NULL,
  `date_added` date default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `clientdetails`
-- 

INSERT INTO `clientdetails` (`surname`, `othername`, `client_id`, `address`, `gender`, `bankname`, `birth_date`, `nationality`, `division`, `location`, `sublocation`, `email`, `mobile_no`, `added_by`, `date_added`) VALUES 
('beatrice', 'jones', 1234, 'p.o box 4061 nakuru', 'female', 'equity', '0000-00-00', 'KENYAN', 'DUNDORI', 'BAHATI', 'MUGWATHI', 'beatoshi@yahoo.com', 727650122, 'beato', '2013-04-20'),
('cynthia', 'nduta', 2222, 'p.o box 4061 nakuru', 'female', 'KCB', '0000-00-00', 'KENYAN', 'DUNDORI', 'BAHATI', 'MUGWATHI', 'cynthianduta@yahoo.com', 727650122, 'beato', '2013-04-20'),
('wesley', 'ochieng', 12345, '1234', 'male', 'equity', '0000-00-00', 'kenyan', 'kiamaitu', 'thika', 'kiamaitu', 'wesley@yahoo.com', 72235478, 'beato', '2013-04-20');

-- --------------------------------------------------------

-- 
-- Table structure for table `deposit`
-- 

CREATE TABLE `deposit` (
  `deposit_id` int(11) NOT NULL auto_increment,
  `bankname` varchar(11) default NULL,
  `client_id` int(11) default NULL,
  `cash_deposit` float default NULL,
  `dep_date` datetime default NULL,
  PRIMARY KEY  (`deposit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

-- 
-- Dumping data for table `deposit`
-- 

INSERT INTO `deposit` (`deposit_id`, `bankname`, `client_id`, `cash_deposit`, `dep_date`) VALUES 
(12, 'equity', 25757551, 12000, '2011-04-27 00:00:00'),
(13, 'KCB', 25757551, 10000, '2011-04-27 00:00:00'),
(14, 'equity', 25757551, 5000, '2011-04-27 00:00:00'),
(15, 'equity', 25757551, 100, '2011-04-27 06:28:21'),
(16, 'equity', 25757551, 20000, '2011-04-27 06:31:33'),
(17, 'equity', 1234, 5000, '2013-04-20 13:36:12'),
(18, 'equity', 1234, 500, '2013-04-20 14:21:13'),
(19, 'equity', 1234, 500, '2013-04-20 15:28:08');

-- --------------------------------------------------------

-- 
-- Table structure for table `kinsdetails`
-- 

CREATE TABLE `kinsdetails` (
  `client_id` int(11) default NULL,
  `kins_name` varchar(40) default NULL,
  `occupation` varchar(15) default NULL,
  `kinid` int(11) NOT NULL,
  `address` varchar(20) default NULL,
  `phone_no` int(11) default NULL,
  `town` varchar(15) default NULL,
  `relationship` varchar(10) default NULL,
  PRIMARY KEY  (`kinid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `kinsdetails`
-- 

INSERT INTO `kinsdetails` (`client_id`, `kins_name`, `occupation`, `kinid`, `address`, `phone_no`, `town`, `relationship`) VALUES 
(1234, 'waithaka', 'drug lord', 1234, '123', 3453, 'nairobi', 'brother'),
(12345, 'MARY', 'MANAGER', 1234567, 'P.O BOX 627 NAIROBI', 725622812, 'NAIROBI', 'FRIEND'),
(25757551, 'ZIPPIE', 'MANAGER', 6578980, 'P.O BOX 67 NAIROBI', 719510077, 'NAIROBI', 'WIFE'),
(12345, 'PETER', 'ODHIAMBO', 9878956, 'P.O BOX 67 NAIROBI', 733546589, 'KISUMU', 'FRIEND'),
(25757551, 'ZIPPIE', 'MANAGER', 65789800, 'P.O BOX 67 NAIROBI', 719510077, 'NAIROBI', 'WIFE'),
(25757551, 'ANN', 'LECTURE', 676768990, 'P.O BOX 67 NAIROBI', 727853812, 'NAKURU', 'MOTHER');

-- --------------------------------------------------------

-- 
-- Table structure for table `pindetails`
-- 

CREATE TABLE `pindetails` (
  `client_id` int(11) default NULL,
  `atm_pin` varchar(11) default NULL,
  `atm_no` int(11) NOT NULL,
  `secrete_word` varchar(15) default NULL,
  PRIMARY KEY  (`atm_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `pindetails`
-- 

INSERT INTO `pindetails` (`client_id`, `atm_pin`, `atm_no`, `secrete_word`) VALUES 
(1234, '1234bb', 1234, '2013-04-20 12:0'),
(12345, '12345', 12345, '2011-04-27 18:0'),
(25757551, '12', 25757551, '2011-04-27 06:0');

-- --------------------------------------------------------

-- 
-- Table structure for table `tcash`
-- 

CREATE TABLE `tcash` (
  `bankname` varchar(15) default NULL,
  `totalcash` float default NULL,
  `client_id` int(11) default NULL,
  `date` datetime default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `tcash`
-- 

INSERT INTO `tcash` (`bankname`, `totalcash`, `client_id`, `date`) VALUES 
('equity', 69000, 1234, '2013-04-20 06:31:33'),
('equity', 50000, 2222, '2013-04-20 00:00:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `transfer`
-- 

CREATE TABLE `transfer` (
  `transfer_id` int(11) NOT NULL auto_increment,
  `client_id` int(11) default NULL,
  `transfer_to` varchar(15) default NULL,
  `transfer_from` varchar(15) default NULL,
  `tranfer_date` datetime default NULL,
  `transfer_amount` float default NULL,
  PRIMARY KEY  (`transfer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `transfer`
-- 

INSERT INTO `transfer` (`transfer_id`, `client_id`, `transfer_to`, `transfer_from`, `tranfer_date`, `transfer_amount`) VALUES 
(1, 1234, 'kcb', 'equity', '2013-04-20 00:00:00', 20000),
(2, 2222, 'kcb', 'equity', '2013-04-20 06:36:26', 10000),
(4, 1234, 'KCB', 'equity', '2013-04-20 12:41:38', 20000),
(5, 1234, 'KCB', 'equity', '2013-04-20 12:42:47', 1000),
(6, 1234, 'NATIONAL', 'equity', '2013-04-20 18:30:13', 4000);

-- --------------------------------------------------------

-- 
-- Table structure for table `withdraw`
-- 

CREATE TABLE `withdraw` (
  `withdraw_id` int(11) NOT NULL auto_increment,
  `bankname` varchar(11) default NULL,
  `client_id` int(11) default NULL,
  `cash_withdraw` float default NULL,
  `withdraw_date` datetime default NULL,
  PRIMARY KEY  (`withdraw_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `withdraw`
-- 

INSERT INTO `withdraw` (`withdraw_id`, `bankname`, `client_id`, `cash_withdraw`, `withdraw_date`) VALUES 
(1, 'equity', 1234, 50000, '2013-04-20 00:00:00'),
(4, 'equity', 2222, 50, '2013-04-20 06:28:21'),
(5, 'equity', 1234, 5000, '2013-04-20 13:36:12'),
(6, 'equity', 1234, 500, '2013-04-20 14:21:13'),
(7, 'equity', 1234, 500, '2013-04-20 15:28:08');

-- --------------------------------------------------------

-- 
-- Table structure for table `you`
-- 

CREATE TABLE `you` (
  `clientid` int(11) NOT NULL default '0',
  `amount` float default NULL,
  `date` varchar(20) default NULL,
  PRIMARY KEY  (`clientid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `you`
-- 

INSERT INTO `you` (`clientid`, `amount`, `date`) VALUES 
(123, 12343, '12233244');
